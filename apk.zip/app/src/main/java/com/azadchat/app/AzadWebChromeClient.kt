package com.azadchat.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * مجوز میکروفون مستقیم از اندروید (فقط برای دامنهٔ خودت) + انتخاب فایل برای آپلود (آواتار، فایل، عکس).
 */
class AzadWebChromeClient(
    private val activity: ComponentActivity,
    private val allowedHost: String
) : WebChromeClient() {

    private var pending: PermissionRequest? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val micLauncher = activity.registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val req = pending
        pending = null
        if (req != null) {
            if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else req.deny()
        }
    }

    private val fileLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = filePathCallback
        filePathCallback = null
        cb?.onReceiveValue(FileChooserParams.parseResult(res.resultCode, res.data))
    }

    override fun onPermissionRequest(request: PermissionRequest) {
        activity.runOnUiThread {
            val host = request.origin?.host
            val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
            if (host != allowedHost || !wantsMic) {
                request.deny(); return@runOnUiThread
            }
            val has = ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (has) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else {
                pending?.deny()
                pending = request
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    override fun onPermissionRequestCanceled(request: PermissionRequest) {
        if (pending === request) pending = null
    }

    override fun onShowFileChooser(
        webView: WebView,
        callback: ValueCallback<Array<Uri>>,
        params: FileChooserParams
    ): Boolean {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback
        return try {
            fileLauncher.launch(params.createIntent())
            true
        } catch (e: Exception) {
            filePathCallback = null
            callback.onReceiveValue(null)
            false
        }
    }
}
