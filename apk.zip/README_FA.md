# AzadChat Android (WebView)
- آدرس سایت: `app/build.gradle` ← `SITE_HOST` و `SITE_URL`
- پکیج: com.azadchat.app — نسخه: 1.59 (versionCode 159)
- شامل: پل اثر انگشت بومی، میکروفون مستقیم، انتخاب/آپلود فایل، دانلود، دکمهٔ برگشت
- امضا: `app/azad-release.keystore` (رمز: azadchat123) — برای آپدیت روی نسخهٔ قبلی همین کلید را نگه دار
